# Stage 3b - repair report

Source store: `/kaggle/input/datasets/zahrasamir/stage3b-subtype-outputs/predictions_subtype.parquet` (16,786 rows)
MIN_CLASS_SUPPORT = 5; bootstrap = stratified, 2000 replicates; APPLY_REPARSE = True

## R1 scope reconstruction

| task | core ids | full ids |
|---|---|---|
| subtype_all | 218 | 491 |
| subtype_top4 | 200 | 341 |
| subtype_top6 | 200 | 415 |

## R2 few-shot sign flips introduced by unpaired k=0

| model | task | k | gain (full frame, strict) | gain (paired) |
|---|---|---|---|---|
| qwen2.5-3b-instruct | subtype_all | 1 | -0.0086 | +0.0245 |
| qwen2.5-3b-instruct | subtype_all | 2 | -0.0212 | +0.0120 |
| smollm3-3b | subtype_all | 1 | +0.0121 | -0.0049 |
| smollm3-3b | subtype_top6 | 2 | +0.0061 | -0.0026 |

## R3 effect of strict scoring (unparseable = wrong)

| model | task | view | prompt | k | parse rate | parsed-only | strict | delta |
|---|---|---|---|---|---|---|---|---|
| qwen2.5-3b-instruct | subtype_all | core | base | 1 | 0.931 | 0.5549 | 0.5340 | -0.0210 |
| qwen2.5-3b-instruct | subtype_all | core | base | 2 | 0.945 | 0.5414 | 0.5214 | -0.0200 |
| qwen2.5-3b-instruct | subtype_all | full | base | 0 | 0.947 | 0.5603 | 0.5426 | -0.0178 |
| qwen2.5-3b-instruct | subtype_all | core | base | 0 | 0.940 | 0.5213 | 0.5094 | -0.0119 |
| qwen2.5-3b-instruct | subtype_top6 | full | base | 0 | 0.983 | 0.6964 | 0.6885 | -0.0079 |
| qwen2.5-7b-instruct | subtype_all | core | base | 0 | 0.973 | 0.6130 | 0.6060 | -0.0070 |
| qwen2.5-7b-instruct | subtype_all | core | terse | 0 | 0.986 | 0.5950 | 0.5905 | -0.0045 |
| qwen2.5-7b-instruct | subtype_all | full | base | 0 | 0.974 | 0.5802 | 0.5760 | -0.0042 |
| qwen2.5-7b-instruct | subtype_all | core | verbose | 0 | 0.995 | 0.6298 | 0.6264 | -0.0035 |
| qwen2.5-3b-instruct | subtype_top4 | core | base | 2 | 0.995 | 0.8216 | 0.8190 | -0.0026 |
| qwen2.5-7b-instruct | subtype_all | core | base | 2 | 0.995 | 0.7445 | 0.7423 | -0.0021 |
| qwen2.5-3b-instruct | subtype_top6 | core | base | 0 | 0.995 | 0.6807 | 0.6793 | -0.0015 |
| gemma-2-2b-it | subtype_top6 | core | base | 1 | 0.995 | 0.7488 | 0.7473 | -0.0015 |
| smollm3-3b | subtype_top6 | core | base | 1 | 0.995 | 0.7103 | 0.7089 | -0.0013 |
| smollm3-3b | subtype_all | core | base | 1 | 0.995 | 0.4949 | 0.4938 | -0.0010 |
| gemma-2-2b-it | subtype_all | full | base | 0 | 0.996 | 0.5281 | 0.5272 | -0.0009 |
| gemma-2-2b-it | subtype_all | core | base | 0 | 0.995 | 0.5542 | 0.5534 | -0.0008 |

## R5 cells not reportable at min support 5

| model | task | view | n | macro-F1 (strict) | min support | underpowered |
|---|---|---|---|---|---|---|
| gemini-3.1-flash-lite | subtype_all | core | 60 | 0.7889 | 1 | availability=1;fault_tolerance=4;legal=4;look_and_feel=2;maintainability=1;portability=2;scalability=1 |
| groq-llama-3.3-70b-versatile | subtype_all | core | 163 | 0.7524 | 4 | maintainability=4 |
| gemini-3.1-flash-lite | subtype_top6 | core | 60 | 0.7894 | 2 | availability=2 |

## R6 parser audit

Positional matching changes 0 of 16786 predictions (0.00%). Applied: True.
